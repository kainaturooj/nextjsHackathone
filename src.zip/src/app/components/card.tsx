// import React from 'react'
// interface CardProps {
//     src: string;
//     alt: string;
//     para : string
//     title: string;
//     content: string;
   
//     button1Text: string;
//     button2Text: string;




//       }
 
   

// const Card = ({src , title , content , para , alt }:CardProps) => {
//   return (
//     <div className="cardCon w-[1000px] h-[700px] bg-re-400 ml-[150px] mr-[100px]">
//     <div className=" mx-auto w-[1000px] ">
//       {/* Image Section */}
//       <div className="h-full w-full">
//         {/* <Image src={src} alt={alt} width={1000} height={700}></Image> */}
        
//       </div>

//       {/* Content Section */}
//       <div className=" h-[270px] flex flex-col items-center bg-slat-600 relative top-[50px]">
//         <p className='  text-[#111111] font-bold text-xl '>{para}</p>
//         <h2 className="text-7xl font-bold text-[#111111] mt-[20px]">{title}</h2>
//         <p className="text-[#111111] font-semibol text-[18px] w-[620px] bg-re-600 text-center mt-[20px]">
//           {content}
//         </p>

//         {/* Buttons */}
//         <div className="mt-[35px] flex space-x-2 ">
//           <button className="px-5 py-3 bg-[#111111] text-white rounded-full ">
//            {button1Text}
//           </button>
//           <button className="px-7 py-3 bg-[#111111] text-white rounded-full ">
//            {button2Text}
//           </button>
//         </div>
//       </div>
//     </div>
//     </div>




   
//   )
// }

// export default Card